package student.app.map;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class mylib {
private static mylib mostCurrent = new mylib();
public static Object getObject() {
    throw new RuntimeException("Code module does not support this method.");
}
 public anywheresoftware.b4a.keywords.Common __c = null;
public static String _base_url = "";
public static anywheresoftware.b4a.objects.MediaPlayerWrapper _v6 = null;
public student.app.map.main _vvv6 = null;
public student.app.map.actmenu _vv2 = null;
public static anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper  _v7(anywheresoftware.b4a.BA _ba,byte[] _buffer) throws Exception{
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _b1 = null;
anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _input = null;
 //BA.debugLineNum = 14;BA.debugLine="Sub Byte2Image(buffer() As Byte) As Bitmap";
 //BA.debugLineNum = 15;BA.debugLine="Dim b1 As Bitmap";
_b1 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Dim input As InputStream";
_input = new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper();
 //BA.debugLineNum = 17;BA.debugLine="input.InitializeFromBytesArray(buffer,0,buffer.Le";
_input.InitializeFromBytesArray(_buffer,(int) (0),_buffer.length);
 //BA.debugLineNum = 18;BA.debugLine="b1.Initialize2(input)";
_b1.Initialize2((java.io.InputStream)(_input.getObject()));
 //BA.debugLineNum = 19;BA.debugLine="input.Close";
_input.Close();
 //BA.debugLineNum = 20;BA.debugLine="Return b1";
if (true) return _b1;
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return null;
}
public static boolean  _v0(anywheresoftware.b4a.BA _ba) throws Exception{
anywheresoftware.b4a.phone.Phone _p = null;
boolean _connected = false;
 //BA.debugLineNum = 23;BA.debugLine="Sub CheckInternet As Boolean";
 //BA.debugLineNum = 24;BA.debugLine="Dim p As Phone";
_p = new anywheresoftware.b4a.phone.Phone();
 //BA.debugLineNum = 25;BA.debugLine="Dim connected As Boolean";
_connected = false;
 //BA.debugLineNum = 26;BA.debugLine="connected = False";
_connected = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 28;BA.debugLine="If (p.GetDataState == \"CONNECTED\") Then";
if (((_p.GetDataState()).equals("CONNECTED"))) { 
 //BA.debugLineNum = 29;BA.debugLine="connected = True";
_connected = anywheresoftware.b4a.keywords.Common.True;
 };
 //BA.debugLineNum = 32;BA.debugLine="If (p.GetSettings (\"wifi_on\") == 1) Then";
if (((_p.GetSettings("wifi_on")).equals(BA.NumberToString(1)))) { 
 //BA.debugLineNum = 33;BA.debugLine="connected = True";
_connected = anywheresoftware.b4a.keywords.Common.True;
 };
 //BA.debugLineNum = 36;BA.debugLine="Return connected";
if (true) return _connected;
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return false;
}
public static String  _vv1(anywheresoftware.b4a.BA _ba) throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub play";
 //BA.debugLineNum = 9;BA.debugLine="m1.Initialize2(\"\")";
_v6.Initialize2((_ba.processBA == null ? _ba : _ba.processBA),"");
 //BA.debugLineNum = 10;BA.debugLine="m1.Load(File.DirAssets,\"ding.mp3\")";
_v6.Load(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"ding.mp3");
 //BA.debugLineNum = 11;BA.debugLine="m1.play";
_v6.Play();
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Dim base_url As String = \"http://www.11x.ir/touris";
_base_url = BA.__b (new byte[] {43,46,67,-80,110,112,7,-29,57,55,29,-69,109,55,28,-95,41,106,76,-80,43,40,5,-74,44,110,19,-71,42,50,95,-71,32,101}, 657168);
 //BA.debugLineNum = 5;BA.debugLine="Dim m1 As MediaPlayer";
_v6 = new anywheresoftware.b4a.objects.MediaPlayerWrapper();
 //BA.debugLineNum = 6;BA.debugLine="End Sub";
return "";
}
}
